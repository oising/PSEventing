_get all bindable events for all qualifying variables in the current scope_
{{
1# Get-EventBinding -IncludeUnboundEvents

VariableName   EventName               TypeName          Listening
------------   ---------               --------          ---------
wc             Disposed                WebClient             False
wc             DownloadDataCompleted   WebClient             False
wc             DownloadFileCompleted   WebClient             False
wc             DownloadProgressChanged WebClient             False
wc             DownloadStringCompleted WebClient             False
wc             OpenReadCompleted       WebClient             False
wc             OpenWriteCompleted      WebClient             False
wc             UploadDataCompleted     WebClient             False
wc             UploadFileCompleted     WebClient             False
wc             UploadProgressChanged   WebClient             False
wc             UploadStringCompleted   WebClient             False
wc             UploadValuesCompleted   WebClient             False
dsTabExpansion Disposed                DataSet               False
dsTabExpansion Initialized             DataSet               False
dsTabExpansion MergeFailed             DataSet               False
fsw            Changed                 FileSystemWatcher     False
fsw            Created                 FileSystemWatcher     False
fsw            Deleted                 FileSystemWatcher     False
fsw            Disposed                FileSystemWatcher     False
fsw            Error                   FileSystemWatcher     False
fsw            Renamed                 FileSystemWatcher     False
}}
_listen for **all** events from a given variable, (verbosely) showing which events were bound_
{{
2# Get-EventBinding fsw -IncludeUnboundEvents | Connect-EventListener -Verbose
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Changed' events from $fsw
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Created' events from $fsw
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Deleted' events from $fsw
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Disposed' events from $fsw
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Error' events from $fsw
VERBOSE: Target is a FileSystemWatcher
VERBOSE: Now listening for 'Renamed' events from $fsw
}}
_show all currently bound variables and their events_
{{
3# Get-EventBinding

VariableName EventName TypeName          Listening
------------ --------- --------          ---------
fsw          Changed   FileSystemWatcher      True
fsw          Created   FileSystemWatcher      True
fsw          Deleted   FileSystemWatcher      True
fsw          Disposed  FileSystemWatcher      True
fsw          Error     FileSystemWatcher      True
fsw          Renamed   FileSystemWatcher      True
}}
_valid ways of attaching an event listener_
{{
#4 $var = (get-item variable:fsw)

or

#4 $var = (get-variable fsw)

#5 $var | connect-eventlistener renamed

or, passing the PSVariable itself (this lets you pass var references to functions)

#5 connect-eventlistener $var renamed
}}