& "$env:windir\Microsoft.NET\Framework\v2.0.50727\InstallUtil.exe" nivot.powershell.eventing.dll
add-pssnapin pseventing
get-help about_pseventing | more
